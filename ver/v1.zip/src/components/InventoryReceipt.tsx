import { useState, useRef, useEffect, useCallback } from 'react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import QRCodeLib from 'qrcode';

interface Item {
  id: number;
  name: string;
  qty: number;
  unit: string;
  price: number;
}

const UNIT_OPTIONS = ['pc', 'kg', 'ltr', 'pkt', 'dz', 'box', 'gm', 'ml', 'mtr', 'set', 'bdl', 'tin', 'can', 'dozen', 'pair', 'bottle', 'packet', 'sachet', 'strip'];

interface PresetGroup {
  category: string;
  items: { name: string; data: { shop: string; tagline: string; phone: string; address: string; items: { name: string; qty: number; unit: string; price: number }[] } }[];
}

const PRESET_GROUPS: PresetGroup[] = [
  {
    category: '🛒 Kirana & General Store',
    items: [
      { name: 'Apna Kirana', data: { shop: 'APNA KIRANA STORE', tagline: '⭐ Roz Ka Samaan Ek Hi Jagah ⭐', phone: '+91 98765 43210', address: 'Main Road, Market Chowk', items: [
        { name: 'Chini (Sugar)', qty: 2, unit: 'kg', price: 48 }, { name: 'Chai Patti (Tea)', qty: 1, unit: 'pkt', price: 120 },
        { name: 'Aata 10kg', qty: 1, unit: 'pkt', price: 380 }, { name: 'Chawal Basmati', qty: 5, unit: 'kg', price: 85 },
        { name: 'Dal Toor', qty: 1, unit: 'kg', price: 140 }, { name: 'Dal Moong', qty: 500, unit: 'gm', price: 90 },
        { name: 'Namak (Salt)', qty: 1, unit: 'pkt', price: 20 }, { name: 'Haldi Powder', qty: 200, unit: 'gm', price: 35 },
        { name: 'Mirchi Powder', qty: 200, unit: 'gm', price: 45 }, { name: 'Tel (Oil) Refined', qty: 1, unit: 'ltr', price: 165 },
        { name: 'Doodh (Milk) Pkt', qty: 2, unit: 'pkt', price: 58 }, { name: 'Ande (Eggs)', qty: 12, unit: 'pc', price: 8 },
      ]}},
      { name: 'Chai Wala Saman', data: { shop: 'CHAI & NASHTA CORNER', tagline: '☕ Chai Ke Liye Sab Kuch ☕', phone: '+91 98765 43211', address: 'Station Road, Bus Stand', items: [
        { name: 'Chai Patti (Assam)', qty: 1, unit: 'kg', price: 320 }, { name: 'Doodh (Milk)', qty: 5, unit: 'ltr', price: 58 },
        { name: 'Cheeni (Sugar)', qty: 3, unit: 'kg', price: 48 }, { name: 'Adrak (Ginger)', qty: 250, unit: 'gm', price: 40 },
        { name: 'Elaichi (Cardamom)', qty: 50, unit: 'gm', price: 120 }, { name: 'Biscuit Pack', qty: 5, unit: 'pkt', price: 25 },
        { name: 'Namkeen Mixture', qty: 2, unit: 'pkt', price: 45 }, { name: 'Bread Sliced', qty: 2, unit: 'pkt', price: 35 },
        { name: 'Butter Block', qty: 1, unit: 'pc', price: 60 }, { name: 'Ketchup Sachet', qty: 50, unit: 'pc', price: 2 },
      ]}},
      { name: 'Monthly Kirana', data: { shop: 'SHARMA GENERAL STORE', tagline: '🥫 Mahine Ka Samaan Mahine Bharr ⭐', phone: '+91 98765 43212', address: 'Gali No. 4, Patel Nagar', items: [
        { name: 'Aata Fortified', qty: 10, unit: 'kg', price: 38 }, { name: 'Chawal (Rice)', qty: 5, unit: 'kg', price: 55 },
        { name: 'Dal Mix', qty: 2, unit: 'kg', price: 130 }, { name: 'Masoor Dal', qty: 1, unit: 'kg', price: 75 },
        { name: 'Chole (Chickpeas)', qty: 2, unit: 'kg', price: 85 }, { name: 'Maida (Flour)', qty: 2, unit: 'kg', price: 35 },
        { name: 'Suji (Semolina)', qty: 1, unit: 'kg', price: 40 }, { name: 'Besan (Gram Flour)', qty: 1, unit: 'kg', price: 75 },
        { name: 'Tel (Mustard Oil)', qty: 2, unit: 'ltr', price: 185 }, { name: 'Ghee', qty: 1, unit: 'ltr', price: 520 },
        { name: 'Sugar 5kg', qty: 1, unit: 'pkt', price: 240 }, { name: 'Tea 1kg', qty: 1, unit: 'pkt', price: 320 },
        { name: 'Salt Crystal', qty: 2, unit: 'kg', price: 12 }, { name: 'Red Chilli Whole', qty: 250, unit: 'gm', price: 55 },
      ]}},
      { name: 'Party Supplies', data: { shop: 'PREMIUM MART', tagline: '🎉 Party Ka Complete Package 🎉', phone: '+91 98765 43213', address: 'Sector 12, Market Complex', items: [
        { name: 'Cold Drink (2L)', qty: 6, unit: 'bottle', price: 85 }, { name: 'Chips Family Pack', qty: 5, unit: 'pkt', price: 75 },
        { name: 'Namkeen Party Mix', qty: 4, unit: 'pkt', price: 55 }, { name: 'Juice (1L) Tetrapack', qty: 4, unit: 'pc', price: 95 },
        { name: 'Water Bottle 1L', qty: 12, unit: 'pc', price: 20 }, { name: 'Paper Cup (50)', qty: 2, unit: 'pkt', price: 35 },
        { name: 'Plate Disposable (25)', qty: 3, unit: 'pkt', price: 40 }, { name: 'Biscuit Assorted', qty: 3, unit: 'pkt', price: 85 },
        { name: 'Cake (Vanilla)', qty: 1, unit: 'kg', price: 450 }, { name: 'Candle Set', qty: 1, unit: 'pkt', price: 35 },
      ]}},
    ]
  },
  {
    category: '🥬 Sabzi Mandi (Vegetables)',
    items: [
      { name: 'Daily Sabzi', data: { shop: 'FRESH VEGETABLE MART', tagline: '🌿 Taaza Sabzi Har Roz 🌿', phone: '+91 98765 43214', address: 'Sabzi Mandi, Nehru Nagar', items: [
        { name: 'Aloo (Potato)', qty: 3, unit: 'kg', price: 30 }, { name: 'Pyaz (Onion)', qty: 2, unit: 'kg', price: 40 },
        { name: 'Tamatar (Tomato)', qty: 1, unit: 'kg', price: 35 }, { name: 'Gobhi (Cauliflower)', qty: 1, unit: 'pc', price: 30 },
        { name: 'Bandh Gobhi (Cabbage)', qty: 1, unit: 'pc', price: 25 }, { name: 'Bhindi (Lady Finger)', qty: 500, unit: 'gm', price: 35 },
        { name: 'Baingan (Brinjal)', qty: 500, unit: 'gm', price: 30 }, { name: 'Karela (Bitter Gourd)', qty: 250, unit: 'gm', price: 25 },
      ]}},
      { name: 'Khatti-Meethi', data: { shop: 'HARIYALI SABZI STORE', tagline: '🍋 Khaas Sabziyon Ka Khaas ⭐', phone: '+91 98765 43215', address: 'Gandhi Chowk Market', items: [
        { name: 'Palak (Spinach)', qty: 2, unit: 'bdl', price: 15 }, { name: 'Methi (Fenugreek)', qty: 2, unit: 'bdl', price: 12 },
        { name: 'Dhania (Coriander)', qty: 3, unit: 'bdl', price: 10 }, { name: 'Pudina (Mint)', qty: 2, unit: 'bdl', price: 8 },
        { name: 'Nimbu (Lemon)', qty: 6, unit: 'pc', price: 8 }, { name: 'Adrak (Ginger)', qty: 250, unit: 'gm', price: 40 },
        { name: 'Lahsun (Garlic)', qty: 200, unit: 'gm', price: 35 }, { name: 'Mirchi (Green Chilli)', qty: 100, unit: 'gm', price: 25 },
      ]}},
      { name: 'Sabzi Stock', data: { shop: 'BHAGAT JI SABZI WALE', tagline: '🥦 Tokri Bhar Ke Le Jaye 🥦', phone: '+91 98765 43216', address: 'Subhash Nagar, Gali No. 7', items: [
        { name: 'Aloo (Potato) 10kg', qty: 1, unit: 'bdl', price: 280 }, { name: 'Pyaz (Onion) 5kg', qty: 1, unit: 'bdl', price: 180 },
        { name: 'Tamatar Box', qty: 1, unit: 'box', price: 320 }, { name: 'Matar (Peas)', qty: 1, unit: 'kg', price: 60 },
        { name: 'Shimla Mirch (Capsicum)', qty: 500, unit: 'gm', price: 45 }, { name: 'Gajar (Carrot)', qty: 1, unit: 'kg', price: 40 },
        { name: 'Mooli (Radish)', qty: 500, unit: 'gm', price: 20 }, { name: 'Chukandar (Beetroot)', qty: 500, unit: 'gm', price: 35 },
        { name: 'Kadddu (Pumpkin)', qty: 1, unit: 'kg', price: 25 }, { name: 'Tori (Ridge Gourd)', qty: 500, unit: 'gm', price: 30 },
      ]}},
    ]
  },
  {
    category: '🍬 Mithai & Namkeen (Sweets & Snacks)',
    items: [
      { name: 'Mithai Ghar', data: { shop: 'SWEET PARADISE MITHALAY', tagline: '🍯 Meetha Jo Dil Jeet Le 🍯', phone: '+91 98765 43217', address: 'Chauraha Bazaar, Main Road', items: [
        { name: 'Rasgulla (1kg)', qty: 500, unit: 'gm', price: 200 }, { name: 'Jalebi (500gm)', qty: 500, unit: 'gm', price: 160 },
        { name: 'Ladoo (MotiChoor)', qty: 8, unit: 'pc', price: 35 }, { name: 'Barfi (Kaju)', qty: 500, unit: 'gm', price: 420 },
        { name: 'Gulab Jamun (1kg)', qty: 1, unit: 'kg', price: 300 }, { name: 'Soan Papdi', qty: 250, unit: 'gm', price: 120 },
        { name: 'Peda (Khoa)', qty: 500, unit: 'gm', price: 280 }, { name: 'Cham Cham', qty: 500, unit: 'gm', price: 240 },
      ]}},
      { name: 'Namkeen Bhandar', data: { shop: 'NAMAK KEEDA CENTRE', tagline: '🧂 Chura-Namkeen Ka Swad 🧂', phone: '+91 98765 43218', address: 'Station Road, Near Bus Stand', items: [
        { name: 'Aloo Bhujia', qty: 500, unit: 'gm', price: 85 }, { name: 'Moong Dal', qty: 250, unit: 'gm', price: 60 },
        { name: 'Khatta Meetha', qty: 500, unit: 'gm', price: 90 }, { name: 'Chana Jor', qty: 250, unit: 'gm', price: 35 },
        { name: 'Dal Mixture', qty: 500, unit: 'gm', price: 75 }, { name: 'Bhujia Sev', qty: 250, unit: 'gm', price: 50 },
        { name: 'Nimish Plain', qty: 500, unit: 'gm', price: 65 }, { name: 'Kachori Aloo', qty: 6, unit: 'pc', price: 15 },
        { name: 'Samosa Fried', qty: 10, unit: 'pc', price: 12 }, { name: 'Papad Roasted', qty: 12, unit: 'pc', price: 5 },
      ]}},
      { name: 'Cookie & Biscuit', data: { shop: 'MITHAS KOOKEEZ', tagline: '🍪 Chai Ke Saath Perfect 🍪', phone: '+91 98765 43219', address: 'Mall Road, Shop No. 5', items: [
        { name: 'Marie Gold', qty: 3, unit: 'pkt', price: 35 }, { name: 'Parle G', qty: 5, unit: 'pkt', price: 10 },
        { name: 'Bourbon', qty: 2, unit: 'pkt', price: 40 }, { name: 'Hide & Seek', qty: 2, unit: 'pkt', price: 55 },
        { name: 'Good Day (Cashew)', qty: 3, unit: 'pkt', price: 45 }, { name: 'Britannia Cake', qty: 2, unit: 'pkt', price: 35 },
        { name: 'Cream Biscuit (Assorted)', qty: 2, unit: 'pkt', price: 65 }, { name: 'Rusk (Toast)', qty: 2, unit: 'pkt', price: 40 },
      ]}},
    ]
  },
  {
    category: '🔧 Hardware & Electronics',
    items: [
      { name: 'Hardware Saman', data: { shop: 'SHARMA HARDWARE STORE', tagline: '🔩 Chhota Kaam Bada Kaam 🔩', phone: '+91 98765 43220', address: 'Loha Mandi, Industrial Area', items: [
        { name: 'Keel (Nails) 1kg', qty: 1, unit: 'kg', price: 80 }, { name: 'Cement Bag', qty: 2, unit: 'bdl', price: 380 },
        { name: 'Paint White 1L', qty: 1, unit: 'ltr', price: 220 }, { name: 'Paint Brush 2"', qty: 2, unit: 'pc', price: 45 },
        { name: 'Taar (Wire) 10m', qty: 1, unit: 'roll', price: 150 }, { name: 'Switch Board', qty: 2, unit: 'pc', price: 85 },
        { name: 'Bulb LED 12W', qty: 4, unit: 'pc', price: 60 }, { name: 'Socket (5A)', qty: 3, unit: 'pc', price: 25 },
        { name: 'Fevicol 50gm', qty: 1, unit: 'pc', price: 35 }, { name: 'Screw Set (50)', qty: 1, unit: 'pkt', price: 40 },
      ]}},
      { name: 'Bijli Ka Saman', data: { shop: 'ELECTRIC MART', tagline: '💡 Roshni Ka Vyapar 💡', phone: '+91 98765 43221', address: 'Bijli Ghar Road', items: [
        { name: 'Tube Light 36W', qty: 2, unit: 'pc', price: 180 }, { name: 'Holder (Batten)', qty: 5, unit: 'pc', price: 15 },
        { name: 'Switch 1 Way', qty: 6, unit: 'pc', price: 18 }, { name: 'MCB 16A', qty: 1, unit: 'pc', price: 145 },
        { name: 'Wire Copper 1.5mm (10m)', qty: 1, unit: 'roll', price: 320 }, { name: 'Tape Electric', qty: 2, unit: 'pc', price: 20 },
        { name: 'Plug Top', qty: 4, unit: 'pc', price: 12 }, { name: 'Fan Regulator', qty: 1, unit: 'pc', price: 120 },
      ]}},
    ]
  },
  {
    category: '🧴 Beauty & Personal Care',
    items: [
      { name: 'Stationery Items', data: { shop: 'PAPER & PEN STORE', tagline: '📚 Pads-Pen-Pencil Sab Kuch 📚', phone: '+91 98765 43222', address: 'School Road, Education Hub', items: [
        { name: 'Copy Single Line', qty: 5, unit: 'pc', price: 25 }, { name: 'Pen (Ball) pack 10', qty: 1, unit: 'pkt', price: 50 },
        { name: 'Pencil (Natraj)', qty: 6, unit: 'pc', price: 8 }, { name: 'Eraser', qty: 3, unit: 'pc', price: 5 },
        { name: 'Sharpener', qty: 3, unit: 'pc', price: 5 }, { name: 'Scale 12"', qty: 2, unit: 'pc', price: 15 },
        { name: 'Glue Stick', qty: 2, unit: 'pc', price: 20 }, { name: 'Notebook 200pg', qty: 2, unit: 'pc', price: 65 },
      ]}},
      { name: 'Cosmetics', data: { shop: 'SHRINGAR COSMETICS', tagline: '💄 Khubsurti Ka Samaan 💄', phone: '+91 98765 43223', address: 'Fashion Street', items: [
        { name: 'Face Cream Ponds', qty: 1, unit: 'pc', price: 120 }, { name: 'Shampoo Sachet', qty: 20, unit: 'pc', price: 5 },
        { name: 'Soap Lux/Pears', qty: 6, unit: 'pc', price: 35 }, { name: 'Toothpaste', qty: 2, unit: 'pc', price: 80 },
        { name: 'Hair Oil Coconut', qty: 1, unit: 'bottle', price: 95 }, { name: 'Comb', qty: 2, unit: 'pc', price: 15 },
        { name: 'Nail Cutter', qty: 1, unit: 'pc', price: 25 }, { name: 'Towel Cotton', qty: 2, unit: 'pc', price: 120 },
      ]}},
      { name: 'Medical Basics', data: { shop: 'JAN AUSHADHI MEDICAL', tagline: '💊 Swasthya Ki Suraksha 💊', phone: '+91 98765 43224', address: 'Hospital Road', items: [
        { name: 'Dettol Soap', qty: 3, unit: 'pc', price: 45 }, { name: 'Band Aid (20)', qty: 2, unit: 'pkt', price: 25 },
        { name: 'Sanitizer 100ml', qty: 2, unit: 'bottle', price: 45 }, { name: 'Paracetamol Tab (10)', qty: 2, unit: 'strip', price: 15 },
        { name: 'Vicks Vaporub', qty: 1, unit: 'pc', price: 85 }, { name: 'Cotton Ball (50gm)', qty: 1, unit: 'pkt', price: 35 },
        { name: 'Moov Spray', qty: 1, unit: 'pc', price: 95 }, { name: 'ORS (5 sachet)', qty: 2, unit: 'pkt', price: 18 },
      ]}},
    ]
  },
  {
    category: '🍗 Non-Veg & Poultry',
    items: [
      { name: 'Chicken Fish', data: { shop: 'FRESH MEAT & FISH', tagline: '🥩 Taaza Maas Har Roz 🥩', phone: '+91 98765 43225', address: 'Non-Veg Market, Gali No 2', items: [
        { name: 'Chicken (Skinless) kg', qty: 2, unit: 'kg', price: 170 }, { name: 'Mutton kg', qty: 1, unit: 'kg', price: 580 },
        { name: 'Fish (Rohu) kg', qty: 1, unit: 'kg', price: 320 }, { name: 'Eggs (Farm Fresh)', qty: 30, unit: 'pc', price: 8 },
        { name: 'Prawns kg', qty: 500, unit: 'gm', price: 380 }, { name: 'Chicken Leg Piece', qty: 6, unit: 'pc', price: 35 },
        { name: 'Mutton Bones', qty: 500, unit: 'gm', price: 120 }, { name: 'Fish (Bangda)', qty: 500, unit: 'gm', price: 180 },
      ]}},
    ]
  },
  {
    category: '🥛 Dairy & Milk Products',
    items: [
      { name: 'Dairy Products', data: { shop: 'GAUSHALA DAIRY FARM', tagline: '🥛 Shuddh Doodh Aur Uske Products 🥛', phone: '+91 98765 43226', address: 'Dairy Farm Road, Gaon Ke Paas', items: [
        { name: 'Doodh (Milk) 1L', qty: 4, unit: 'ltr', price: 58 }, { name: 'Dahi (Curd) 500gm', qty: 2, unit: 'pkt', price: 40 },
        { name: 'Butter (Amul) 100gm', qty: 1, unit: 'pc', price: 55 }, { name: 'Paneer (Fresh) 250gm', qty: 2, unit: 'pkt', price: 90 },
        { name: 'Cheese Slice', qty: 1, unit: 'pkt', price: 75 }, { name: 'Ghee (Desi) 1L', qty: 1, unit: 'ltr', price: 480 },
        { name: 'Chaach (ButterMilk) 1L', qty: 2, unit: 'ltr', price: 25 }, { name: 'Lassi Sweet 500ml', qty: 2, unit: 'pc', price: 45 },
      ]}},
    ]
  },
  {
    category: '🫘 Masale & Dry Fruits',
    items: [
      { name: 'Masale (Spices)', data: { shop: 'MASALA KING', tagline: '🌶️ Khushbu Aur Swad Ka Raja 🌶️', phone: '+91 98765 43227', address: 'Masala Market, Purana Shehar', items: [
        { name: 'Garam Masala (100gm)', qty: 2, unit: 'pkt', price: 55 }, { name: 'Dhaniya Powder (200gm)', qty: 1, unit: 'pkt', price: 35 },
        { name: 'Jeera (Cumin) 200gm', qty: 1, unit: 'pkt', price: 45 }, { name: 'Amchur (Mango) 100gm', qty: 1, unit: 'pkt', price: 30 },
        { name: 'Chaat Masala (100gm)', qty: 2, unit: 'pkt', price: 25 }, { name: 'Turmeric (Haldi) 200gm', qty: 1, unit: 'pkt', price: 40 },
        { name: 'Red Chilli Powder (200gm)', qty: 1, unit: 'pkt', price: 55 }, { name: 'Kashmiri Mirch (100gm)', qty: 1, unit: 'pkt', price: 40 },
        { name: 'Sarson (Mustard) 200gm', qty: 1, unit: 'pkt', price: 25 }, { name: 'Methi Dana (100gm)', qty: 1, unit: 'pkt', price: 18 },
      ]}},
      { name: 'Dry Fruits', data: { shop: 'KHATTA MEETHA DRY FRUITS', tagline: '🥜 Sehat Aur Mazaa Dono 🥜', phone: '+91 98765 43228', address: 'Fancy Bazaar, Shop No. 12', items: [
        { name: 'Badam (Almond) 250gm', qty: 1, unit: 'pkt', price: 220 }, { name: 'Kaju (Cashew) 250gm', qty: 1, unit: 'pkt', price: 350 },
        { name: 'Kishmish (Raisins) 200gm', qty: 1, unit: 'pkt', price: 120 }, { name: 'Pista 200gm', qty: 1, unit: 'pkt', price: 320 },
        { name: 'Akhrot (Walnut) 250gm', qty: 1, unit: 'pkt', price: 280 }, { name: 'Anjeer (Fig) 200gm', qty: 1, unit: 'pkt', price: 180 },
        { name: 'Khajoor (Dates) 500gm', qty: 1, unit: 'pkt', price: 150 }, { name: 'Makhana (Fox Nut) 200gm', qty: 1, unit: 'pkt', price: 110 },
      ]}},
    ]
  }
];

export default function InventoryReceipt() {
  const [shopName, setShopName] = useState('APNA GENERAL STORE');
  const [shopTagline, setShopTagline] = useState('⭐ Sabse Sasta, Sabse Achha ⭐');
  const [shopPhone, setShopPhone] = useState('+91 98765 43210');
  const [shopAddress, setShopAddress] = useState('Main Bazaar, Market Road');
  const [customerName, setCustomerName] = useState('');
  const [items, setItems] = useState<Item[]>([
    { id: 1, name: 'Chini (Sugar)', qty: 1, unit: 'kg', price: 48 },
    { id: 2, name: 'Chai Patti', qty: 1, unit: 'pkt', price: 120 },
    { id: 3, name: 'Aata (Flour)', qty: 5, unit: 'kg', price: 42 },
    { id: 4, name: 'Sabun (Soap)', qty: 3, unit: 'pc', price: 35 },
    { id: 5, name: 'Tel (Oil)', qty: 1, unit: 'ltr', price: 165 },
  ]);
  const [discount, setDiscount] = useState(0);
  const [taxRate, setTaxRate] = useState(5);
  const [nextId, setNextId] = useState(6);
  const [animate, setAnimate] = useState(false);
  const [viewMode, setViewMode] = useState<'table' | 'card'>('card');
  const [invoiceNo, setInvoiceNo] = useState(`INV-${Date.now().toString().slice(-6)}`);
  const [paymentMode, setPaymentMode] = useState('Cash');
  const [upiId, setUpiId] = useState('');
  const [cashReceived, setCashReceived] = useState(0);
  const [notes, setNotes] = useState('Goods once sold will not be returned.');
  const [exportScale, setExportScale] = useState(4);
  const [qrDataUrl, setQrDataUrl] = useState('');

  const receiptRef = useRef<HTMLDivElement>(null);
  const barcodeRef = useRef<HTMLDivElement>(null);
  const qrRef = useRef<HTMLDivElement>(null);
  const clipperRef = useRef<HTMLDivElement>(null);
  const printBtnRef = useRef<HTMLButtonElement>(null);
  const qrGenerated = useRef(false);

  const addItem = () => {
    setItems([...items, { id: nextId, name: '', qty: 1, unit: 'pc', price: 0 }]);
    setNextId(nextId + 1);
  };

  const removeItem = (id: number) => {
    if (items.length <= 1) return;
    setItems(items.filter(i => i.id !== id));
  };

  const updateItem = (id: number, field: keyof Item, value: string | number) => {
    setItems(items.map(i => i.id === id ? { ...i, [field]: value } : i));
  };

  const subtotal = items.reduce((sum, i) => sum + i.qty * i.price, 0);
  const discountAmt = subtotal * (discount / 100);
  const afterDiscount = subtotal - discountAmt;
  const taxAmt = afterDiscount * (taxRate / 100);
  const grandTotal = afterDiscount + taxAmt;
  const balanceAmount = paymentMode === 'Cash' && cashReceived > 0 ? cashReceived - grandTotal : 0;

  // Generate barcode
  const genBarcode = useCallback(() => {
    if (barcodeRef.current) {
      let html = '';
      for (let i = 0; i < 18; i++) {
        const w = Math.floor(Math.random() * 6) + 2;
        html += `<div style="background:#111;height:30px;width:${w}px;display:inline-block;flex-shrink:0;"></div>`;
      }
      barcodeRef.current.innerHTML = html;
    }
  }, []);

  // Generate QR as a PNG data URL so exports never miss the QR code.
  const genQR = useCallback(() => {
    const qrText = upiId.trim()
      ? `upi://pay?pa=${encodeURIComponent(upiId.trim())}&pn=${encodeURIComponent(shopName)}&am=${grandTotal.toFixed(2)}&cu=INR&tn=${encodeURIComponent(invoiceNo)}`
      : `Invoice: ${invoiceNo} | ${shopName} | Total: ₹${grandTotal.toFixed(2)} | ${new Date().toLocaleDateString('en-IN')}`;

    QRCodeLib.toDataURL(qrText, {
      width: 180,
      margin: 1,
      errorCorrectionLevel: 'H',
      color: { dark: '#000000', light: '#fef9e6' }
    })
      .then(url => {
        setQrDataUrl(url);
        qrGenerated.current = true;
      })
      .catch(e => {
        console.warn('QR gen error, retrying...', e);
        setTimeout(() => genQR(), 300);
      });
  }, [upiId, shopName, grandTotal, invoiceNo]);

  // Barcode + QR on mount and data change
  useEffect(() => {
    genBarcode();
    // Delay QR to ensure DOM is ready
    const timer = setTimeout(() => genQR(), 100);
    return () => clearTimeout(timer);
  }, [genBarcode, genQR]);

  const handlePrint = () => {
    if (clipperRef.current) clipperRef.current.style.maxHeight = '';
    setAnimate(false);
    // Regenerate QR before print
    qrGenerated.current = false;
    setTimeout(() => genQR(), 50);
    void (clipperRef.current?.offsetWidth ?? 0);
    requestAnimationFrame(() => {
      setAnimate(true);
    });
  };

  const exportImage = async () => {
    if (!receiptRef.current) return;
    try {
      // Ensure QR/barcode is fully rendered
      genBarcode();
      genQR();
      await document.fonts.ready;
      await new Promise(r => setTimeout(r, 300));

      const el = receiptRef.current;
      // Temporarily expand the clipper for capture
      const clipper = el.parentElement;
      const origMaxH = clipper?.style.maxHeight || '';
      if (clipper) clipper.style.maxHeight = 'none';
      el.classList.add('receipt-exporting');
      el.style.width = '420px';
      el.style.padding = '18px 14px 14px';

      const canvas = await html2canvas(el, {
        scale: exportScale,
        backgroundColor: '#fef9e6',
        logging: false,
        useCORS: true,
        allowTaint: true,
        width: el.scrollWidth,
        height: el.scrollHeight,
        scrollY: -window.scrollY,
        windowWidth: el.scrollWidth,
        windowHeight: el.scrollHeight,
      });

      // Restore
      if (clipper) clipper.style.maxHeight = origMaxH;
      el.classList.remove('receipt-exporting');
      el.style.width = '';
      el.style.padding = '';

      const a = document.createElement('a');
      a.download = 'invoice.png';
      a.href = canvas.toDataURL('image/png');
      a.click();
    } catch (e) {
      console.error('Export error:', e);
      alert('Image export failed. Try again.');
    }
  };

  const exportPDF = async () => {
    if (!receiptRef.current) return;
    try {
      genBarcode();
      genQR();
      await document.fonts.ready;
      await new Promise(r => setTimeout(r, 300));

      const el = receiptRef.current;
      const clipper = el.parentElement;
      const origMaxH = clipper?.style.maxHeight || '';
      if (clipper) clipper.style.maxHeight = 'none';
      el.classList.add('receipt-exporting');
      el.style.width = '420px';
      el.style.padding = '18px 14px 14px';

      const canvas = await html2canvas(el, {
        scale: Math.max(2, Math.min(exportScale, 4)),
        backgroundColor: '#fef9e6',
        logging: false,
        useCORS: true,
        allowTaint: true,
        width: el.scrollWidth,
        height: el.scrollHeight,
        scrollY: -window.scrollY,
        windowWidth: el.scrollWidth,
        windowHeight: el.scrollHeight,
      });

      if (clipper) clipper.style.maxHeight = origMaxH;
      el.classList.remove('receipt-exporting');
      el.style.width = '';
      el.style.padding = '';

      const imgData = canvas.toDataURL('image/png');
      const pdfHeight = Math.max(90, (canvas.height * 80) / canvas.width + 4);
      const pdf = new jsPDF('p', 'mm', [80, pdfHeight]);
          const imgW = 76;
          const imgH = (canvas.height * imgW) / canvas.width;
          pdf.addImage(imgData, 'PNG', 2, 2, imgW, imgH);
          pdf.save('invoice.pdf');
    } catch (e) {
      console.error('PDF error:', e);
      alert('PDF export failed. Try again.');
    }
  };

  const applyPreset = (preset: { shop: string; tagline: string; phone: string; address: string; items: { name: string; qty: number; unit: string; price: number }[] }) => {
    setShopName(preset.shop);
    setShopTagline(preset.tagline);
    setShopPhone(preset.phone);
    setShopAddress(preset.address);
    const newItems = preset.items.map((it, idx) => ({ id: nextId + idx, ...it }));
    setItems(newItems);
    setNextId(nextId + preset.items.length + 1);
    // Regenerate QR after state update
    setTimeout(() => genQR(), 200);
  };

  return (
    <div className="split-layout">
      {/* LEFT: FORM */}
      <div className="split-col">
        <div className="glass-panel">
          <h2 className="text-xl sm:text-2xl font-semibold mb-4 gradient-amber">🏪 Dukandar Inventory</h2>

          <div className="section-title"><span>🎨 20+ Daily Presets</span></div>
          <div className="flex flex-col gap-3 max-h-[300px] sm:max-h-[400px] overflow-y-auto pr-1 rounded-lg border border-[#2c2c38] p-2 mb-1">
            {PRESET_GROUPS.map((group, gi) => (
              <div key={gi}>
                <div className="text-[11px] uppercase tracking-widest text-amber-500 font-bold mb-1.5 sticky top-0 bg-[#0f0f18] py-1 z-10">{group.category}</div>
                <div className="btn-group">
                  {group.items.map((preset, pi) => (
                    <button key={pi} className="retro-btn" onClick={() => applyPreset(preset.data)}>{preset.name}</button>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="section-title"><span>🏪 Shop Details</span></div>
          <div className="flex flex-col gap-3">
            <div className="input-group">
              <label className="input-label">Dukaan Ka Naam</label>
              <input className="retro-input" value={shopName} onChange={e => setShopName(e.target.value)} />
            </div>
            <div className="input-group">
              <label className="input-label">📢 Tagline</label>
              <input className="retro-input" value={shopTagline} onChange={e => setShopTagline(e.target.value)} />
            </div>
            <div className="input-row">
              <div className="input-group">
                <label className="input-label">📞 Phone</label>
                <input className="retro-input" value={shopPhone} onChange={e => setShopPhone(e.target.value)} />
              </div>
              <div className="input-group">
                <label className="input-label">👤 Customer</label>
                <input className="retro-input" value={customerName} onChange={e => setCustomerName(e.target.value)} placeholder="Walk-in" />
              </div>
            </div>
            <div className="input-group">
              <label className="input-label">📍 Address</label>
              <input className="retro-input" value={shopAddress} onChange={e => setShopAddress(e.target.value)} />
            </div>
          </div>

          <div className="section-title"><span>🧾 Billing & Export</span></div>
          <div className="flex flex-col gap-3">
            <div className="input-row">
              <div className="input-group">
                <label className="input-label">Invoice No.</label>
                <input className="retro-input" value={invoiceNo} onChange={e => setInvoiceNo(e.target.value)} />
              </div>
              <div className="input-group">
                <label className="input-label">Payment Mode</label>
                <select className="retro-select" value={paymentMode} onChange={e => setPaymentMode(e.target.value)}>
                  <option value="Cash">Cash</option>
                  <option value="UPI">UPI</option>
                  <option value="Card">Card</option>
                  <option value="Credit">Credit / Udhaar</option>
                  <option value="Mixed">Mixed</option>
                </select>
              </div>
            </div>
            <div className="input-row">
              <div className="input-group">
                <label className="input-label">UPI ID (for QR)</label>
                <input className="retro-input" value={upiId} onChange={e => setUpiId(e.target.value)} placeholder="shop@upi" />
              </div>
              <div className="input-group">
                <label className="input-label">Cash Received</label>
                <input className="retro-input" type="number" min={0} value={cashReceived} onChange={e => setCashReceived(parseFloat(e.target.value) || 0)} />
              </div>
            </div>
            <div className="input-row">
              <div className="input-group">
                <label className="input-label">Export Quality</label>
                <select className="retro-select" value={exportScale} onChange={e => setExportScale(parseInt(e.target.value, 10))}>
                  <option value={2}>Standard 2x</option>
                  <option value={3}>High 3x</option>
                  <option value={4}>Ultra 4x</option>
                </select>
              </div>
              <div className="input-group">
                <label className="input-label">Bill Notes / Terms</label>
                <input className="retro-input" value={notes} onChange={e => setNotes(e.target.value)} />
              </div>
            </div>
          </div>

          {/* Items */}
          <div className="section-title">
            <span>📦 Items ({items.length})</span>
            <div className="flex gap-1.5 flex-wrap">
              <button
                className={`retro-btn ${viewMode === 'card' ? 'active' : ''}`}
                style={viewMode === 'card' ? { background: '#ffb347', color: '#000', borderColor: '#ffb347' } : {}}
                onClick={() => setViewMode('card')}
              >📱 Cards</button>
              <button
                className={`retro-btn ${viewMode === 'table' ? 'active' : ''}`}
                style={viewMode === 'table' ? { background: '#ffb347', color: '#000', borderColor: '#ffb347' } : {}}
                onClick={() => setViewMode('table')}
              >📊 Table</button>
              <button className="retro-btn" onClick={addItem}>➕ Add</button>
            </div>
          </div>

          {viewMode === 'table' ? (
            <div className="inv-wrapper">
              <div className="inv-scroll">
                <table className="inv-table">
                  <thead>
                    <tr>
                      <th style={{ width: '36px' }}>#</th>
                      <th>Item Name</th>
                      <th style={{ width: '70px' }}>Qty</th>
                      <th style={{ width: '70px' }}>Unit</th>
                      <th style={{ width: '85px' }}>Price</th>
                      <th style={{ width: '85px' }}>Total</th>
                      <th style={{ width: '44px' }}></th>
                    </tr>
                  </thead>
                  <tbody>
                    {items.map((item, idx) => (
                      <tr key={item.id}>
                        <td className="text-gray-500 text-xs font-mono">{idx + 1}</td>
                        <td>
                          <input className="inv-input" value={item.name} onChange={e => updateItem(item.id, 'name', e.target.value)} placeholder="Item..." />
                        </td>
                        <td>
                          <input className="inv-input text-center" type="number" min={0} value={item.qty} onChange={e => updateItem(item.id, 'qty', parseFloat(e.target.value) || 0)} />
                        </td>
                        <td>
                          <select className="inv-input text-center" value={item.unit} onChange={e => updateItem(item.id, 'unit', e.target.value)}>
                            {UNIT_OPTIONS.map(u => <option key={u} value={u}>{u}</option>)}
                          </select>
                        </td>
                        <td>
                          <input className="inv-input text-right" type="number" min={0} step="0.01" value={item.price} onChange={e => updateItem(item.id, 'price', parseFloat(e.target.value) || 0)} />
                        </td>
                        <td className="text-right font-mono text-amber-400 text-sm font-bold whitespace-nowrap">
                          ₹{(item.qty * item.price).toFixed(2)}
                        </td>
                        <td>
                          <button className="inv-remove-btn" onClick={() => removeItem(item.id)} disabled={items.length <= 1}>✕</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div className="flex flex-col gap-2 max-h-[400px] overflow-y-auto pr-0.5">
              {items.length === 0 && (
                <div className="text-center text-gray-500 py-4 text-sm">No items added. Click "➕ Add" or use a preset!</div>
              )}
              {items.map((item, idx) => (
                <div key={item.id} className="bg-[#0f0f18] border border-[#2c2c38] rounded-xl p-3 flex-shrink-0">
                  <div className="flex items-center justify-between mb-2 gap-2">
                    <span className="text-amber-400 font-bold text-sm flex-shrink-0">#{idx + 1}</span>
                    <span className="text-amber-400 font-mono font-bold text-sm whitespace-nowrap flex-1 text-right">
                      ₹{(item.qty * item.price).toFixed(2)}
                    </span>
                    <button className="inv-remove-btn" onClick={() => removeItem(item.id)} disabled={items.length <= 1}>✕</button>
                  </div>
                  <input
                    className="inv-input mb-2"
                    value={item.name}
                    onChange={e => updateItem(item.id, 'name', e.target.value)}
                    placeholder="Item name..."
                  />
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="text-[10px] uppercase text-gray-500 block mb-1">Qty</label>
                      <input
                        className="inv-input text-center"
                        type="number"
                        min={0}
                        value={item.qty}
                        onChange={e => updateItem(item.id, 'qty', parseFloat(e.target.value) || 0)}
                      />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase text-gray-500 block mb-1">Unit</label>
                      <select
                        className="inv-input text-center"
                        value={item.unit}
                        onChange={e => updateItem(item.id, 'unit', e.target.value)}
                      >
                        {UNIT_OPTIONS.map(u => <option key={u} value={u}>{u}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="text-[10px] uppercase text-gray-500 block mb-1">Price ₹</label>
                      <input
                        className="inv-input text-right"
                        type="number"
                        min={0}
                        step="0.01"
                        value={item.price}
                        onChange={e => updateItem(item.id, 'price', parseFloat(e.target.value) || 0)}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="section-title"><span>💸 Discount & Tax</span></div>
          <div className="input-row">
            <div className="input-group">
              <label className="input-label">Discount %</label>
              <input className="retro-input" type="number" min={0} max={100} value={discount} onChange={e => setDiscount(parseFloat(e.target.value) || 0)} />
            </div>
            <div className="input-group">
              <label className="input-label">GST/Tax %</label>
              <input className="retro-input" type="number" min={0} max={50} value={taxRate} onChange={e => setTaxRate(parseFloat(e.target.value) || 0)} />
            </div>
          </div>

          <div className="inv-total-box">
            <div className="inv-total-row">
              <span className="text-gray-400">Subtotal ({items.length} items)</span>
              <span className="text-white">₹{subtotal.toFixed(2)}</span>
            </div>
            {discount > 0 && (
              <div className="inv-total-row">
                <span className="text-green-400">Discount ({discount}%)</span>
                <span className="text-green-400">-₹{discountAmt.toFixed(2)}</span>
              </div>
            )}
            <div className="inv-total-row">
              <span className="text-gray-400">GST ({taxRate}%)</span>
              <span className="text-yellow-400">+₹{taxAmt.toFixed(2)}</span>
            </div>
            <div className="inv-total-row inv-grand-total">
              <span>GRAND TOTAL</span>
              <span>₹{grandTotal.toFixed(2)}</span>
            </div>
          </div>

          <button ref={printBtnRef} className="print-btn mt-4" onClick={handlePrint}>📠 Print Invoice</button>

          <div className="btn-group justify-center mt-3">
            <button className="retro-btn" onClick={exportImage}>🖼️ Image</button>
            <button className="retro-btn" onClick={exportPDF}>📄 PDF</button>
          </div>
        </div>
      </div>

      {/* RIGHT: RECEIPT PREVIEW */}
      <div className="split-col center">
        <div className="printer-machine">
          <div className="paper-slot">
            <div className="slot-mouth"></div>
            <div ref={clipperRef} className={`receipt-clipper ${animate ? 'print-animate' : ''}`}>
              <div className="receipt-content" ref={receiptRef}>
                <div style={{ textAlign: 'center', fontSize: '16px', fontWeight: 800, wordBreak: 'break-word' }}>{shopName}</div>
                <div className="receipt-tagline">{shopTagline}</div>
                <div style={{ textAlign: 'center', fontSize: '10px', wordBreak: 'break-word' }}>📞 {shopPhone}</div>
                <div style={{ textAlign: 'center', fontSize: '10px', wordBreak: 'break-word' }}>📍 {shopAddress}</div>
                <hr className="receipt-hr" />
                <div className="receipt-flex-row"><span>🧾 INVOICE</span><span>{invoiceNo}</span></div>
                <div className="receipt-flex-row"><span>📅 DATE</span><span>{new Date().toLocaleDateString('en-IN')}</span></div>
                <div className="receipt-flex-row"><span>⏰ TIME</span><span>{new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</span></div>
                <div className="receipt-flex-row"><span>💳 PAYMENT</span><span>{paymentMode}</span></div>
                {customerName && <div className="receipt-flex-row"><span>👤 CUSTOMER</span><span>{customerName}</span></div>}
                <div className="receipt-stars">{'='.repeat(26)}</div>

                {/* Items table in receipt */}
                <div style={{ fontSize: '12px' }}>
                  <div className="receipt-flex-row" style={{ fontWeight: 800, borderBottom: '1px solid #333', paddingBottom: '3px' }}>
                    <span style={{ flex: '1 1 auto', minWidth: 0 }}>ITEM</span>
                    <span style={{ width: '36px', textAlign: 'right', flexShrink: 0 }}>QTY</span>
                    <span style={{ width: '44px', textAlign: 'right', flexShrink: 0 }}>RATE</span>
                    <span style={{ width: '55px', textAlign: 'right', flexShrink: 0 }}>AMT</span>
                  </div>
                  {items.map((item, idx) => (
                    <div key={item.id} className="receipt-flex-row" style={{ borderBottom: '1px dotted #ccc', paddingBottom: '2px', alignItems: 'baseline' }}>
                      <span style={{ flex: '1 1 auto', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', minWidth: 0 }}>
                        {idx + 1}. {item.name || '???'}
                      </span>
                      <span style={{ width: '36px', textAlign: 'right', flexShrink: 0, whiteSpace: 'nowrap' }}>{item.qty}{item.unit}</span>
                      <span style={{ width: '44px', textAlign: 'right', flexShrink: 0, whiteSpace: 'nowrap' }}>₹{item.price.toFixed(1)}</span>
                      <span style={{ width: '55px', textAlign: 'right', flexShrink: 0, whiteSpace: 'nowrap', fontWeight: 'bold' }}>₹{(item.qty * item.price).toFixed(1)}</span>
                    </div>
                  ))}
                </div>

                <div className="receipt-stars">{'='.repeat(26)}</div>
                <div className="receipt-flex-row"><span>SUBTOTAL</span><span>₹{subtotal.toFixed(2)}</span></div>
                {discount > 0 && <div className="receipt-flex-row"><span>DISCOUNT ({discount}%)</span><span>-₹{discountAmt.toFixed(2)}</span></div>}
                <div className="receipt-flex-row"><span>GST ({taxRate}%)</span><span>₹{taxAmt.toFixed(2)}</span></div>
                <div className="receipt-flex-row" style={{ fontWeight: 800, fontSize: '15px', borderTop: '2px solid #111', paddingTop: '4px' }}>
                  <span>TOTAL</span><span>₹{grandTotal.toFixed(2)}</span>
                </div>
                {paymentMode === 'Cash' && cashReceived > 0 && (
                  <>
                    <div className="receipt-flex-row"><span>CASH RECEIVED</span><span>₹{cashReceived.toFixed(2)}</span></div>
                    <div className="receipt-flex-row"><span>{balanceAmount >= 0 ? 'CHANGE' : 'DUE'}</span><span>₹{Math.abs(balanceAmount).toFixed(2)}</span></div>
                  </>
                )}
                <hr className="receipt-hr" />
                {notes && <div style={{ fontSize: '9px', textAlign: 'center', marginBottom: '8px', wordBreak: 'break-word' }}>{notes}</div>}
                <div style={{ textAlign: 'center', fontSize: '10px', background: '#e5ddc7', padding: '5px', margin: '10px 0', fontFamily: 'monospace' }}>
                  🙏 THANK YOU! PHIR AAIYEGA! 🙏
                </div>
                <hr className="receipt-hr" />
                <div className="receipt-barcode" ref={barcodeRef}></div>
                <div className="receipt-qr">
                  <div ref={qrRef} id="receiptQR_inv">
                    {qrDataUrl ? <img src={qrDataUrl} alt="Invoice QR" width={80} height={80} /> : <span style={{ fontSize: '9px' }}>QR loading...</span>}
                  </div>
                </div>
                <div className="receipt-footer">{shopName.toUpperCase()}</div>
                <div style={{ fontSize: '9px', textAlign: 'center', marginTop: '6px' }}>⚡ SHUBH LABH ⚡</div>
              </div>
            </div>
          </div>
        </div>
        <p className="text-[11px] text-gray-500 text-center px-2">⬆️ Line-by-line items + auto total + GST + QR</p>
      </div>
    </div>
  );
}
